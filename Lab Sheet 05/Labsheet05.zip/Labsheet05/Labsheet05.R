setwd("C:\\Users\\it24102990\\Desktop\\Labsheet05")
getwd()
#import the data set
#1.
Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE)
fix(Delivery_Times)
print(summary(Delivery_Times))
#attach the data set
attach(Delivery_Times)

#2.
#create the histogram deliver time
histogram<-hist(Delivery_Time_.minutes.,main="Histogram of Deliver Time",breaks =seq(20,70,length=10 ),right = FALSE)

#3. Comment on the shape of the distribution
# The histogram shows a roughly right-skewed distribution. Most delivery times cluster
# between 20-50 minutes, with fewer deliveries taking longer (up to 70 minutes).
# The distribution is not perfectly symmetric, with a longer tail on the right side.


#4.
# Calculate cumulative frequencies for the ogive
freq <- histogram$counts  # Get the counts for each of the 9 bins
cum_freq <- cumsum(freq)  # Cumulative sum of the 9 counts
breaks <- seq(20, 70, length = 10)  # 10 breakpoints for 9 intervals

# Plot cumulative frequency polygon (ogive)
plot(breaks, c(0, cum_freq),
     type = "l",
     main = "Cumulative Frequency Polygon (Ogive) of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")
points(breaks, c(0, cum_freq), pch = 16, col = "blue")  # Add points for clarity

